<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-box">
            <h1 class="auth-title"><?php echo APP_NAME; ?></h1>
            <h2>Đăng nhập</h2>
            
            <?php
            if (isset($_SESSION['message'])) {
                echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['message']) . '</div>';
                unset($_SESSION['message']);
            }
            if (isset($_SESSION['errors'])) {
                foreach ($_SESSION['errors'] as $error) {
                    echo '<div class="alert alert-error">' . htmlspecialchars($error) . '</div>';
                }
                unset($_SESSION['errors']);
            }
            if (isset($_GET['timeout'])) {
                echo '<div class="alert alert-error">Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại.</div>';
            }
            ?>
            
            <form action="api/login.php" method="POST" class="auth-form">
                <div class="form-group">
                    <input type="text" name="username" placeholder="Tên đăng nhập" required>
                </div>
                
                <div class="form-group">
                    <input type="password" name="password" placeholder="Mật khẩu" required>
                </div>
                
                <button type="submit" class="btn-primary btn-block">Đăng nhập</button>
            </form>
            
            <p class="auth-link">Chưa có tài khoản? <a href="register.php">Đăng ký ngay</a></p>
            
            <!-- Add admin demo credentials note -->
            <div style="margin-top: 2rem; padding: 1rem; background: #f0f0f0; border-radius: 8px; font-size: 0.85rem; color: #666;">
                <strong>Demo Admin:</strong><br>
                Username: admin<br>
                Password: admin123
            </div>
        </div>
    </div>
    
    <?php include 'components/footer.php'; ?>
    <script src="js/main.js"></script>
</body>
</html>
