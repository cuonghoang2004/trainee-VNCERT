# SocialHub - Mạng Xã Hội PHP

Ứng dụng mạng xã hội hoàn chỉnh được xây dựng bằng PHP thuần với HTML và CSS.

## Tính Năng

### Cho Người Dùng
- ✅ **Đăng ký & Đăng nhập** - Tạo tài khoản với mật khẩu bảo mật (hashing)
- ✅ **Đăng bài viết** - Chia sẻ suy nghĩ và ý kiến
- ✅ **Chỉnh sửa/Xóa bài** - Quản lý nội dung của mình
- ✅ **Thích bài viết** - Tương tác với nội dung yêu thích
- ✅ **Bình luận** - Thảo luận với cộng đồng
- ✅ **Tìm kiếm** - Tìm bài viết và người dùng
- ✅ **Hồ sơ cá nhân** - Xem và chỉnh sửa thông tin
- ✅ **Khám phá xu hướng** - Xem những hashtag phổ biến

### Cho Quản Trị Viên
- ✅ **Bảng điều khiển** - Xem thống kê toàn bộ hệ thống
- ✅ **Quản lý người dùng** - Xem danh sách người dùng
- ✅ **Quản lý bài viết** - Xóa bài viết vi phạm
- ✅ **Phân quyền** - Quản lý vai trò (User, Admin, Moderator)

## Yêu Cầu Hệ Thống

- PHP 7.4+
- MySQL 5.7+
- Web Server (Apache/Nginx)
- XAMPP, WAMP, hoặc LAMP

## Hướng Dẫn Cài Đặt

### 1. Chuẩn Bị Cơ Sở Dữ Liệu

\`\`\`bash
# Truy cập MySQL
mysql -u root -p

# Chạy script cài đặt
source scripts/01-database-setup.sql
source scripts/02-add-admin-roles.sql
\`\`\`

### 2. Cấu Hình Ứng Dụng

Chỉnh sửa file `config.php`:

\`\`\`php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_NAME', 'social_network');
\`\`\`

### 3. Cài Đặt Tệp

1. Copy toàn bộ folder vào thư mục web của bạn:
   - XAMPP: `htdocs/social_network`
   - WAMP: `www/social_network`
   - LAMP: `/var/www/html/social_network`

2. Truy cập: `http://localhost/social_network`

### 4. Tài Khoản Demo

**Admin:**
- Username: `admin`
- Password: `admin123`

**Người dùng thông thường:** Đăng ký tài khoản mới

## Cấu Trúc Dự Án

\`\`\`
social_network/
├── api/
│   ├── login.php          # Xử lý đăng nhập
│   ├── register.php       # Xử lý đăng ký
│   ├── logout.php         # Xử lý đăng xuất
│   ├── post.php           # Tạo bài viết
│   ├── edit-post.php      # Chỉnh sửa bài viết
│   ├── delete-post.php    # Xóa bài viết
│   ├── comment.php        # Thêm bình luận
│   ├── like.php           # Thích bài viết
│   └── search.php         # Tìm kiếm
├── admin/
│   ├── dashboard.php      # Bảng điều khiển
│   ├── users.php          # Quản lý người dùng
│   └── posts.php          # Quản lý bài viết
├── components/
│   ├── header.php         # Header chung
│   ├── footer.php         # Footer chung
│   ├── sidebar.php        # Sidebar trái
│   ├── post-card.php      # Thành phần bài viết
│   └── trending.php       # Xu hướng
├── css/
│   └── style.css          # Stylesheet chính
├── js/
│   └── main.js            # JavaScript chính
├── scripts/
│   ├── 01-database-setup.sql      # Script tạo database
│   └── 02-add-admin-roles.sql     # Script thêm admin roles
├── uploads/               # Thư mục lưu ảnh (tạo tự động)
├── config.php             # Cấu hình ứng dụng
├── index.php              # Trang chủ
├── login.php              # Trang đăng nhập
├── register.php           # Trang đăng ký
├── profile.php            # Trang hồ sơ cá nhân
├── edit-profile.php       # Trang chỉnh sửa hồ sơ
├── search.php             # Trang tìm kiếm
└── README.md              # Tài liệu này
\`\`\`

## Cơ Sở Dữ Liệu

### Bảng Users
\`\`\`sql
- id (INT, PRIMARY KEY)
- username (VARCHAR, UNIQUE)
- email (VARCHAR, UNIQUE)
- password (VARCHAR)
- full_name (VARCHAR)
- avatar (VARCHAR)
- bio (TEXT)
- role (ENUM: user, admin, moderator)
- created_at (TIMESTAMP)
\`\`\`

### Bảng Posts
\`\`\`sql
- id (INT, PRIMARY KEY)
- user_id (INT, FOREIGN KEY)
- content (TEXT)
- image (VARCHAR)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
\`\`\`

### Bảng Comments
\`\`\`sql
- id (INT, PRIMARY KEY)
- post_id (INT, FOREIGN KEY)
- user_id (INT, FOREIGN KEY)
- content (TEXT)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
\`\`\`

### Bảng Post_Likes & Comment_Likes
\`\`\`sql
- id (INT, PRIMARY KEY)
- post_id / comment_id (INT, FOREIGN KEY)
- user_id (INT, FOREIGN KEY)
- created_at (TIMESTAMP)
- UNIQUE (post_id/comment_id, user_id)
\`\`\`

## Tính Năng Bảo Mật

✅ **Password Hashing** - Sử dụng `password_hash()` với `PASSWORD_DEFAULT`
✅ **SQL Injection Prevention** - Prepared Statements với Parametrized Queries
✅ **XSS Protection** - Sử dụng `htmlspecialchars()` cho tất cả output
✅ **CSRF Protection** - Session-based validation
✅ **Role-Based Access Control** - Kiểm tra quyền hạn cho mỗi action
✅ **Session Timeout** - Tự động logout sau 1 giờ không hoạt động
✅ **Input Validation** - Kiểm tra độ dài và định dạng dữ liệu

## API Endpoints

### Authentication
- `POST /api/register.php` - Đăng ký
- `POST /api/login.php` - Đăng nhập
- `GET /api/logout.php` - Đăng xuất

### Posts
- `POST /api/post.php` - Tạo bài viết
- `POST /api/edit-post.php` - Chỉnh sửa bài viết
- `POST /api/delete-post.php` - Xóa bài viết

### Interactions
- `POST /api/like.php` - Thích/Bỏ thích bài viết
- `POST /api/comment.php` - Thêm bình luận

### Search
- `GET /search.php?q=query` - Tìm kiếm

## Hướng Phát Triển

### Cải Tiến Tương Lai
- [ ] Upload ảnh đại diện
- [ ] Notifications (Thông báo)
- [ ] Followers/Following
- [ ] Direct Messages
- [ ] Hashtags tự động
- [ ] Pagination cho danh sách
- [ ] Dark mode
- [ ] Mobile app
- [ ] API RESTful
- [ ] WebSockets cho real-time updates

## Troubleshooting

### Lỗi kết nối cơ sở dữ liệu
- Kiểm tra cài đặt trong `config.php`
- Đảm bảo MySQL đang chạy
- Kiểm tra username/password

### Lỗi 404 Not Found
- Kiểm tra tên folder đúng
- Đảm bảo file PHP tồn tại
- Kiểm tra cấu hình rewrite rules

### Lỗi "Truy cập bị từ chối"
- Đảm bảo bạn đã đăng nhập
- Kiểm tra quyền hạn của tài khoản
- Chỉ admin mới có thể truy cập trang quản trị

## Liên Hệ & Hỗ Trợ

Để báo cáo lỗi hoặc đề xuất tính năng, vui lòng:
- Gửi issue trên GitHub
- Gửi email đến: contact@socialhub.com

## License

MIT License - Tự do sử dụng và phân phối

## Tác Giả

Được tạo bằng v0 - Vercel AI Code Generation
