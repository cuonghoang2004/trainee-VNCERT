<?php 
include 'config.php';

requireLogin();

$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'components/header.php'; ?>
    
    <main class="main-container">
        <div class="sidebar">
            <?php include 'components/sidebar.php'; ?>
        </div>
        
        <div class="feed">
            <!-- Enhanced profile header with edit button -->
            <div class="profile-header">
                <img src="<?php echo htmlspecialchars($user['avatar'] ?? '/placeholder.svg?height=150&width=150'); ?>" alt="Avatar" class="profile-avatar">
                <div class="profile-info">
                    <h1><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h1>
                    <p class="profile-username">@<?php echo htmlspecialchars($user['username']); ?></p>
                    <p class="profile-bio"><?php echo htmlspecialchars($user['bio'] ?? 'Chưa có thông tin'); ?></p>
                    <p class="profile-joined">Tham gia từ <?php echo date('d/m/Y', strtotime($user['created_at'])); ?></p>
                    <a href="edit-profile.php" class="btn-primary">Chỉnh sửa hồ sơ</a>
                </div>
                <?php if (isAdmin($user)): ?>
                    <div class="admin-badge">
                        <span>👑 Quản trị viên</span>
                        <a href="admin/dashboard.php" class="btn-secondary">Bảng điều khiển</a>
                    </div>
                <?php endif; ?>
            </div>
            
            <h2>Bài viết của tôi</h2>
            <div class="posts-list">
                <?php
                $conn = connectDB();
                $stmt = $conn->prepare("
                    SELECT p.*, u.username, u.avatar, u.id as user_id,
                           (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as likes_count,
                           (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                           (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id AND user_id = ?) as is_liked
                    FROM posts p
                    JOIN users u ON p.user_id = u.id
                    WHERE p.user_id = ?
                    ORDER BY p.created_at DESC
                ");
                $stmt->bind_param("ii", $_SESSION['user_id'], $_SESSION['user_id']);
                $stmt->execute();
                $posts = $stmt->get_result();
                
                if ($posts->num_rows > 0) {
                    while ($post = $posts->fetch_assoc()) {
                        include 'components/post-card.php';
                    }
                } else {
                    echo '<div class="empty-state"><p>Chưa có bài viết nào</p></div>';
                }
                
                $stmt->close();
                $conn->close();
                ?>
            </div>
        </div>
    </main>
    
    <?php include 'components/footer.php'; ?>
    <script src="js/main.js"></script>
</body>
</html>
