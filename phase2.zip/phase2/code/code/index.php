<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Mạng xã hội</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'components/header.php'; ?>
    
    <main class="main-container">
        <div class="sidebar">
            <?php include 'components/sidebar.php'; ?>
        </div>
        
        <div class="feed">
            <?php if (isLoggedIn()): ?>
                <div class="post-composer">
                    <form action="api/post.php" method="POST">
                        <input type="text" name="title" placeholder="Tiêu đề bài viết" maxlength="255" required>
                        <textarea name="content" placeholder="Bạn đang nghĩ gì?" required></textarea>
                        <button type="submit" class="btn-primary">Đăng bài</button>
                    </form>
                </div>
            <?php endif; ?>
            
            <div class="posts-list">
                <?php
                $conn = connectDB();
                
                if (isLoggedIn()) {
                    $user_id = $_SESSION['user_id'];
                    $stmt = $conn->prepare("
                        SELECT p.*, u.username, u.avatar, u.id as user_id,
                               (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as likes_count,
                               (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                               (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id AND user_id = ?) as is_liked
                        FROM posts p
                        JOIN users u ON p.user_id = u.id
                        ORDER BY p.created_at DESC
                        LIMIT 50
                    ");
                    $stmt->bind_param("i", $user_id);
                } else {
                    $stmt = $conn->prepare("
                        SELECT p.*, u.username, u.avatar, u.id as user_id,
                               (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as likes_count,
                               (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                               0 as is_liked
                        FROM posts p
                        JOIN users u ON p.user_id = u.id
                        ORDER BY p.created_at DESC
                        LIMIT 50
                    ");
                }
                
                $stmt->execute();
                $posts = $stmt->get_result();
                
                if ($posts->num_rows > 0) {
                    while ($post = $posts->fetch_assoc()) {
                        include 'components/post-card.php';
                    }
                } else {
                    echo '<div class="empty-state"><p>Chưa có bài viết nào</p></div>';
                }
                
                $stmt->close();
                $conn->close();
                ?>
            </div>
        </div>
        
        <div class="sidebar-right">
            <?php include 'components/trending.php'; ?>
        </div>
    </main>
    
    <?php include 'components/footer.php'; ?>
    <script src="js/main.js"></script>
</body>
</html>
