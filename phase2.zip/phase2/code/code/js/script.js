document.addEventListener("DOMContentLoaded", () => {
  // Like button functionality
  const likeButtons = document.querySelectorAll(".btn-like[data-post-id]")

  likeButtons.forEach((button) => {
    button.addEventListener("click", async function (e) {
      e.preventDefault()

      const postId = this.getAttribute("data-post-id")

      try {
        const response = await fetch("api/like.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: "post_id=" + postId,
        })

        if (!response.ok) {
          console.error("Error:", response.statusText)
          return
        }

        const data = await response.json()

        // Update button appearance
        this.classList.toggle("liked", data.liked)
        this.innerHTML = (data.liked ? "❤️" : "🤍") + " (" + data.count + ")"
      } catch (error) {
        console.error("Error:", error)
      }
    })
  })

  // Comment form submission
  const commentForms = document.querySelectorAll(".comment-form")

  commentForms.forEach((form) => {
    form.addEventListener("submit", async function (e) {
      e.preventDefault()

      const postId = this.getAttribute("data-post-id")
      const input = this.querySelector(".comment-input")
      const content = input.value.trim()

      if (!content) return

      try {
        const response = await fetch("api/comment.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: "post_id=" + postId + "&content=" + encodeURIComponent(content),
        })

        if (!response.ok) {
          console.error("Error:", response.statusText)
          return
        }

        input.value = ""
        location.reload() // Reload to show new comment
      } catch (error) {
        console.error("Error:", error)
      }
    })
  })
})
