document.addEventListener("DOMContentLoaded", () => {
  // Like button functionality
  const likeButtons = document.querySelectorAll(".btn-like[data-post-id]")

  likeButtons.forEach((button) => {
    button.addEventListener("click", async function (e) {
      e.preventDefault()

      const postId = this.getAttribute("data-post-id")

      try {
        const response = await fetch("api/like.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: "post_id=" + postId,
        })

        if (!response.ok) {
          console.error("[v0] Like error:", response.statusText)
          return
        }

        const data = await response.json()

        // Update button appearance
        this.classList.toggle("liked", data.liked)
        this.innerHTML = (data.liked ? "❤️" : "🤍") + " (" + data.count + ")"
      } catch (error) {
        console.error("[v0] Like fetch error:", error)
      }
    })
  })

  // Comment form submission
  const commentForms = document.querySelectorAll(".comment-form")

  commentForms.forEach((form) => {
    form.addEventListener("submit", async function (e) {
      e.preventDefault()

      const postId = this.getAttribute("data-post-id")
      const input = this.querySelector(".comment-input")
      const content = input.value.trim()

      if (!content) return

      try {
        const response = await fetch("api/comment.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: "post_id=" + postId + "&content=" + encodeURIComponent(content),
        })

        if (!response.ok) {
          console.error("[v0] Comment error:", response.statusText)
          return
        }

        input.value = ""
        location.reload()
      } catch (error) {
        console.error("[v0] Comment fetch error:", error)
      }
    })
  })

  // Edit post functionality
  const editButtons = document.querySelectorAll(".btn-edit[data-post-id]")
  editButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault()
      const postId = this.getAttribute("data-post-id")
      const postContent = this.getAttribute("data-content")
      const postTitle = this.getAttribute("data-title") || ""

      const newTitle = prompt("Tiêu đề mới:", postTitle)
      if (newTitle === null) return
      const newContent = prompt("Nội dung mới:", postContent)
      if (newContent === null) return

      if (newTitle.trim() && newContent.trim()) {
        editPost(postId, newContent.trim(), newTitle.trim())
      }
    })
  })

  // Delete post functionality
  const deleteButtons = document.querySelectorAll(".btn-delete[data-post-id]")
  deleteButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault()
      if (confirm("Bạn có chắc muốn xóa bài viết này?")) {
        const postId = this.getAttribute("data-post-id")
        deletePost(postId)
      }
    })
  })

  // Search form
  const searchForm = document.querySelector(".search-bar form")
  if (searchForm) {
    searchForm.addEventListener("submit", function (e) {
      const query = this.querySelector("input[name='q']").value.trim()
      if (!query) {
        e.preventDefault()
        alert("Vui lòng nhập từ khóa tìm kiếm")
      }
    })
  }

  // Alert auto-close
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.transition = "opacity 0.5s ease"
      alert.style.opacity = "0"
      setTimeout(() => alert.remove(), 500)
    }, 5000)
  })
})

// Edit post function
async function editPost(postId, content, title) {
  try {
    const response = await fetch("api/edit-post.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body:
        "post_id=" +
        postId +
        "&content=" +
        encodeURIComponent(content) +
        "&title=" +
        encodeURIComponent(title || ""),
    })

    if (!response.ok) {
      alert("Lỗi khi cập nhật bài viết")
      return
    }

    location.reload()
  } catch (error) {
    console.error("[v0] Edit post error:", error)
    alert("Lỗi khi cập nhật bài viết")
  }
}

// Delete post function
async function deletePost(postId) {
  try {
    const response = await fetch("api/delete-post.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: "post_id=" + postId,
    })

    if (!response.ok) {
      alert("Lỗi khi xóa bài viết")
      return
    }

    location.reload()
  } catch (error) {
    console.error("[v0] Delete post error:", error)
    alert("Lỗi khi xóa bài viết")
  }
}

// Theme toggle (optional)
function toggleTheme() {
  document.body.classList.toggle("dark-mode")
  localStorage.setItem("theme", document.body.classList.contains("dark-mode") ? "dark" : "light")
}

// Initialize theme from localStorage
window.addEventListener("load", () => {
  const theme = localStorage.getItem("theme")
  if (theme === "dark") {
    document.body.classList.add("dark-mode")
  }
})
