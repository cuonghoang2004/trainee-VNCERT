<?php
if (!isLoggedIn()) {
    echo '<p>Vui lòng <a href="login.php">đăng nhập</a> để sử dụng tất cả tính năng</p>';
} else {
    $user = getCurrentUser();
    ?>
    <div class="user-profile-card">
        <div class="user-avatar">
            <img src="<?php echo htmlspecialchars($user['avatar'] ?? '/placeholder.svg?height=60&width=60'); ?>" alt="Avatar">
        </div>
        <h3><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h3>
        <p class="username">@<?php echo htmlspecialchars($user['username']); ?></p>
        <p class="bio"><?php echo htmlspecialchars($user['bio'] ?? 'Chưa có thông tin'); ?></p>
        
        <!-- Add edit profile button -->
        <a href="edit-profile.php" class="btn-primary" style="display: block; margin-top: 1rem; text-align: center; padding: 0.5rem;">Chỉnh sửa</a>
    </div>
    
    <nav class="sidebar-menu">
        <ul>
            <li><a href="index.php">📰 Trang chủ</a></li>
            <li><a href="profile.php">👤 Hồ sơ</a></li>
            
            <!-- Add admin menu if user is admin -->
            <?php if (isAdmin($user)): ?>
                <li style="margin-top: 1rem; font-weight: bold; color: var(--primary);">⚙️ Quản trị</li>
                <li><a href="admin/dashboard.php">📊 Bảng điều khiển</a></li>
                <li><a href="admin/users.php">👥 Quản lý người dùng</a></li>
                <li><a href="admin/posts.php">📝 Quản lý bài viết</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <?php
}
?>
