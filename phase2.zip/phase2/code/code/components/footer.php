<?php
?>
<footer class="footer">
    <div class="footer-container">
        <div class="footer-content">
            <div class="footer-section">
                <h4><?php echo APP_NAME; ?></h4>
                <p>Mạng xã hội kết nối mọi người.</p>
            </div>
            
            <div class="footer-section">
                <h5>Liên kết</h5>
                <ul>
                    <li><a href="index.php">Trang chủ</a></li>
                    <li><a href="search.php">Tìm kiếm</a></li>
                    <?php if (isLoggedIn()): ?>
                        <li><a href="profile.php">Hồ sơ của tôi</a></li>
                        <li><a href="edit-profile.php">Chỉnh sửa hồ sơ</a></li>
                    <?php else: ?>
                        <li><a href="login.php">Đăng nhập</a></li>
                        <li><a href="register.php">Đăng ký</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            
            <div class="footer-section">
                <h5>Quản trị</h5>
                <ul>
                    <?php if (isLoggedIn() && isAdmin(getCurrentUser())): ?>
                        <li><a href="admin/dashboard.php">Bảng điều khiển</a></li>
                        <li><a href="admin/users.php">Quản lý người dùng</a></li>
                        <li><a href="admin/posts.php">Quản lý bài viết</a></li>
                    <?php endif; ?>
                    <li><a href="#">Chính sách bảo mật</a></li>
                    <li><a href="#">Điều khoản dịch vụ</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h5>Liên hệ</h5>
                <p>Email: contact@socialhub.com</p>
                <p>Điện thoại: +84 123 456 789</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 <?php echo APP_NAME; ?>. Tất cả quyền được bảo lưu.</p>
        </div>
    </div>
</footer>
