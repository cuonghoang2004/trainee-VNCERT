<div class="trending-card">
    <h3>🔥 Xu hướng hôm nay</h3>
    <ul class="trending-list">
        <li><a href="?search=%23PHP">#PHP</a> <span>1.2K bài viết</span></li>
        <li><a href="?search=%23WebDevelopment">#WebDevelopment</a> <span>856 bài viết</span></li>
        <li><a href="?search=%23SocialMedia">#SocialMedia</a> <span>623 bài viết</span></li>
        <li><a href="?search=%23Coding">#Coding</a> <span>512 bài viết</span></li>
        <li><a href="?search=%23Technology">#Technology</a> <span>445 bài viết</span></li>
    </ul>
</div>
