<?php
$current_user = getCurrentUser();
?>
<header class="header">
    <div class="header-container">
        <div class="logo">
            <!-- Use APP_NAME constant instead of hardcoded text -->
            <!-- Use absolute path so admin pages return to main feed -->
            <h1><a href="/code/index.php"><?php echo APP_NAME; ?></a></h1>
        </div>
        
        <div class="search-bar">
            <form action="search.php" method="GET">
                <input type="text" name="q" placeholder="Tìm kiếm bài viết, người dùng..." required>
                <button type="submit">🔍</button>
            </form>
        </div>
        
        <nav class="nav">
            <?php if ($current_user): ?>
                <span class="welcome">Xin chào, <?php echo htmlspecialchars($current_user['username']); ?></span>
                <?php if (isAdmin($current_user)): ?>
                    <a href="admin/dashboard.php" class="btn-secondary" style="font-size: 0.8rem;">👑 Admin</a>
                <?php endif; ?>
                <a href="api/logout.php" class="btn-logout">Đăng xuất</a>
            <?php else: ?>
                <a href="login.php" class="btn-secondary">Đăng nhập</a>
                <a href="register.php" class="btn-primary">Đăng ký</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
