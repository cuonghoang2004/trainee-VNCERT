<div class="post-card">
    <div class="post-header">
        <div class="user-info">
            <img src="<?php echo htmlspecialchars($post['avatar'] ?? '/placeholder.svg?height=40&width=40'); ?>" alt="Avatar" class="avatar-small">
            <div class="user-details">
                <strong><?php echo htmlspecialchars($post['username']); ?></strong>
                <span class="timestamp"><?php echo formatTime($post['created_at']); ?></span>
            </div>
        </div>
        <?php if (isLoggedIn()): 
            $current_user = getCurrentUser();
            $is_owner = $post['user_id'] == $_SESSION['user_id'];
            $is_admin = isAdmin($current_user);
            if ($is_owner || $is_admin): ?>
            <div class="post-menu">
                <?php if ($is_owner): ?>
                    <button class="btn-edit" data-post-id="<?php echo $post['id']; ?>" data-title="<?php echo htmlspecialchars($post['title'] ?? ''); ?>" data-content="<?php echo htmlspecialchars($post['content']); ?>" title="Chỉnh sửa">✏️</button>
                <?php endif; ?>
                <?php if ($is_owner || $is_admin): ?>
                    <button class="btn-delete" data-post-id="<?php echo $post['id']; ?>" title="Xóa">🗑️</button>
                <?php endif; ?>
            </div>
        <?php endif; endif; ?>
    </div>

    <div class="post-content">
        <h3 class="post-title"><?php echo htmlspecialchars($post['title'] ?? '(Không tiêu đề)'); ?></h3>
        <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
    </div>

    <div class="post-stats">
        <span><?php echo $post['likes_count']; ?> thích</span>
        <span><?php echo $post['comments_count']; ?> bình luận</span>
    </div>

    <div class="post-actions">
        <?php if (isLoggedIn()): ?>
            <button class="btn-like" data-post-id="<?php echo $post['id']; ?>" data-liked="<?php echo $post['is_liked'] ? '1' : '0'; ?>">
                <?php echo $post['is_liked'] ? '❤️' : '🤍'; ?> (<?php echo $post['likes_count']; ?>)
            </button>
        <?php else: ?>
            <a href="login.php" class="btn-like">🤍 (<?php echo $post['likes_count']; ?>)</a>
        <?php endif; ?>
    </div>

    <?php if (isLoggedIn()): ?>
    <div class="comments-section">
        <form class="comment-form" data-post-id="<?php echo $post['id']; ?>">
            <input type="text" placeholder="Viết bình luận..." class="comment-input" required>
            <button type="submit">Gửi</button>
        </form>

        <div class="comments-list" id="comments-<?php echo $post['id']; ?>">
            <?php
            // Lấy 5 bình luận mới nhất cho bài viết
            $conn_comments = connectDB();
            $stmt_comments = $conn_comments->prepare("SELECT c.*, u.username, u.avatar, (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id) as likes_count FROM comments c JOIN users u ON c.user_id = u.id WHERE c.post_id = ? ORDER BY c.created_at DESC LIMIT 5");
            $stmt_comments->bind_param("i", $post['id']);
            $stmt_comments->execute();
            $comments = $stmt_comments->get_result();
            while ($comment = $comments->fetch_assoc()): ?>
                <div class="comment">
                    <img src="<?php echo htmlspecialchars($comment['avatar'] ?? '/placeholder.svg?height=30&width=30'); ?>" alt="Avatar" class="avatar-xs">
                    <div class="comment-body">
                        <strong><?php echo htmlspecialchars($comment['username']); ?></strong>
                        <p><?php echo htmlspecialchars($comment['content']); ?></p>
                        <small><?php echo formatTime($comment['created_at']); ?></small>
                    </div>
                </div>
            <?php endwhile; $stmt_comments->close(); $conn_comments->close(); ?>
        </div>
    </div>
    <?php endif; ?>
</div>
