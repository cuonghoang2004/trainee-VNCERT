<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-box">
            <h1 class="auth-title"><?php echo APP_NAME; ?></h1>
            <h2>Đăng ký tài khoản</h2>
            
            <?php
            if (isset($_SESSION['errors'])) {
                foreach ($_SESSION['errors'] as $error) {
                    echo '<div class="alert alert-error">' . htmlspecialchars($error) . '</div>';
                }
                unset($_SESSION['errors']);
            }
            ?>
            
            <form action="api/register.php" method="POST" class="auth-form">
                <div class="form-group">
                    <input type="text" name="username" placeholder="Tên đăng nhập" required>
                </div>
                
                <div class="form-group">
                    <input type="email" name="email" placeholder="Email" required>
                </div>
                
                <div class="form-group">
                    <input type="text" name="full_name" placeholder="Tên đầy đủ">
                </div>
                
                <div class="form-group">
                    <input type="password" name="password" placeholder="Mật khẩu (tối thiểu 6 ký tự)" required>
                </div>
                
                <div class="form-group">
                    <input type="password" name="confirm_password" placeholder="Xác nhận mật khẩu" required>
                </div>
                
                <button type="submit" class="btn-primary btn-block">Đăng ký</button>
            </form>
            
            <p class="auth-link">Đã có tài khoản? <a href="login.php">Đăng nhập</a></p>
        </div>
    </div>
    
    <?php include 'components/footer.php'; ?>
    <script src="js/main.js"></script>
</body>
</html>
