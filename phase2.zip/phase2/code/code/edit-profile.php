<?php
include 'config.php';

requireLogin();

$user = getCurrentUser();
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = escape($_POST['full_name'] ?? '');
    $bio = escape($_POST['bio'] ?? '');
    $email = escape($_POST['email'] ?? '');
    
    if (empty($full_name)) {
        $errors[] = "Tên đầy đủ không được để trống";
    }
    
    if (!isValidEmail($email)) {
        $errors[] = "Email không hợp lệ";
    }
    
    if (strlen($bio) > 500) {
        $errors[] = "Tiểu sử không được vượt quá 500 ký tự";
    }
    
    if (empty($errors)) {
        $conn = connectDB();
        
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, bio = ?, email = ? WHERE id = ?");
        $stmt->bind_param("sssi", $full_name, $bio, $email, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $success = "Hồ sơ đã được cập nhật thành công!";
            $user = getCurrentUser();
        } else {
            $errors[] = "Lỗi khi cập nhật hồ sơ";
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh sửa hồ sơ - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'components/header.php'; ?>
    
    <main class="auth-page">
        <div class="auth-container">
            <div class="auth-box">
                <h2>Chỉnh sửa hồ sơ</h2>
                
                <?php if (!empty($errors)): ?>
                    <?php foreach ($errors as $error): ?>
                        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <form method="POST" class="auth-form">
                    <div class="form-group">
                        <label>Tên đầy đủ:</label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Tiểu sử (max 500 ký tự):</label>
                        <textarea name="bio" maxlength="500" rows="4"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn-primary btn-block">Lưu thay đổi</button>
                </form>
                
                <div class="auth-link">
                    <a href="profile.php">Quay lại hồ sơ</a> | 
                    <a href="change-password.php">Đổi mật khẩu</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'components/footer.php'; ?>
    <script src="js/main.js"></script>
</body>
</html>
