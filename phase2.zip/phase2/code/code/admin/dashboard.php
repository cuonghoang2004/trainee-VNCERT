<?php
include '../config.php';

requireAdmin();

$conn = connectDB();

// Get statistics
$stats = [];

// Total users
$result = $conn->query("SELECT COUNT(*) as count FROM users");
$row = $result->fetch_assoc();
$stats['total_users'] = $row['count'];

// Total posts
$result = $conn->query("SELECT COUNT(*) as count FROM posts");
$row = $result->fetch_assoc();
$stats['total_posts'] = $row['count'];

// Total comments
$result = $conn->query("SELECT COUNT(*) as count FROM comments");
$row = $result->fetch_assoc();
$stats['total_comments'] = $row['count'];

// Recent posts
$stmt = $conn->prepare("
    SELECT p.id, p.content, u.username, p.created_at 
    FROM posts p 
    JOIN users u ON p.user_id = u.id 
    ORDER BY p.created_at DESC 
    LIMIT 10
");
$stmt->execute();
$recent_posts = $stmt->get_result();
$stmt->close();

$conn->close();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bảng điều khiển quản trị - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../components/header.php'; ?>
    
    <main class="main-container">
        <div class="admin-header">
            <h1>Bảng điều khiển quản trị</h1>
        </div>
        
        <div class="admin-stats">
            <div class="stat-card">
                <h3>Tổng người dùng</h3>
                <p class="stat-number"><?php echo $stats['total_users']; ?></p>
            </div>
            <div class="stat-card">
                <h3>Tổng bài viết</h3>
                <p class="stat-number"><?php echo $stats['total_posts']; ?></p>
            </div>
            <div class="stat-card">
                <h3>Tổng bình luận</h3>
                <p class="stat-number"><?php echo $stats['total_comments']; ?></p>
            </div>
        </div>
        
        <div class="admin-section">
            <h2>Quản lý</h2>
            <div class="admin-links">
                <a href="users.php" class="btn-secondary">Quản lý người dùng</a>
                <a href="posts.php" class="btn-secondary">Quản lý bài viết</a>
            </div>
        </div>
        
        <div class="admin-header">
            <h2>Bài viết gần đây</h2>
        </div>
        
        <div class="admin-table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th style="width: 120px;">Người viết</th>
                        <th style="width: 250px;">Nội dung</th>
                        <th style="width: 100px;">Ngày đăng</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($post = $recent_posts->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $post['id']; ?></td>
                            <td><?php echo htmlspecialchars($post['username']); ?></td>
                            <td title="<?php echo htmlspecialchars($post['content']); ?>">
                                <?php 
                                $content = htmlspecialchars($post['content']);
                                echo mb_strlen($content) > 50 ? mb_substr($content, 0, 50) . '...' : $content;
                                ?>
                            </td>
                            <td><?php echo formatTime($post['created_at']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
    
    <?php include '../components/footer.php'; ?>
    <script src="../js/main.js"></script>
</body>
</html>
