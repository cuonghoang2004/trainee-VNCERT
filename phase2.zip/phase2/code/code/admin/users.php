<?php
include '../config.php';

requireAdmin();

$message = $_SESSION['message'] ?? null;
unset($_SESSION['message']);
$errors = $_SESSION['errors'] ?? [];
unset($_SESSION['errors']);

$conn = connectDB();
$stmt = $conn->prepare("SELECT id, username, email, full_name, role, created_at FROM users ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->get_result();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý người dùng - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../components/header.php'; ?>
    
    <main class="main-container">
        <div class="admin-header">
            <h1>Quản lý người dùng</h1>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): foreach ($errors as $err): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($err); ?></div>
        <?php endforeach; endif; ?>

        <section class="admin-card">
            <h2>Thêm người dùng</h2>
            <form method="POST" action="../api/admin-user-create.php" class="admin-form">
                <div class="form-row">
                    <input type="text" name="username" placeholder="Tên đăng nhập" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="text" name="full_name" placeholder="Tên đầy đủ">
                    <input type="password" name="password" placeholder="Mật khẩu" required>
                    <select name="role">
                        <option value="user">user</option>
                        <option value="moderator">moderator</option>
                        <option value="admin">admin</option>
                    </select>
                    <button type="submit" class="btn-primary">Thêm</button>
                </div>
            </form>
        </section>
        
        <div class="admin-table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th style="width: 150px;">Tên đăng nhập</th>
                        <th style="width: 200px;">Email</th>
                        <th style="width: 100px;">Vai trò</th>
                        <th style="width: 100px;">Tạo lúc</th>
                        <th style="width: 150px;">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($user = $users->fetch_assoc()): ?>
                        <tr id="user-row-<?php echo $user['id']; ?>">
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><span class="role-badge role-<?php echo $user['role']; ?>"><?php echo $user['role']; ?></span></td>
                            <td><?php echo formatTime($user['created_at']); ?></td>
                            <td>
                                <button onclick="editUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($user['email'], ENT_QUOTES); ?>', '<?php echo $user['role']; ?>')" class="btn-edit">✏️ Sửa</button>
                                <button onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>')" class="btn-delete">🗑️ Xóa</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
    
    <!-- Edit User Modal -->
    <div id="editModal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Chỉnh sửa người dùng</h2>
            <form id="editForm" method="POST" action="../api/admin-user-update.php">
                <input type="hidden" id="edit_user_id" name="user_id">
                <div class="form-group">
                    <label>Tên đăng nhập:</label>
                    <input type="text" id="edit_username" name="username" required>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" id="edit_email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Vai trò:</label>
                    <select id="edit_role" name="role">
                        <option value="user">user</option>
                        <option value="moderator">moderator</option>
                        <option value="admin">admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Mật khẩu mới (để trống nếu không đổi):</label>
                    <input type="password" id="edit_password" name="password" minlength="6">
                </div>
                <button type="submit" class="btn-primary">Cập nhật</button>
                <button type="button" class="btn-secondary" onclick="closeEditModal()">Hủy</button>
            </form>
        </div>
    </div>

    <?php include '../components/footer.php'; ?>
    <script src="../js/main.js"></script>
    <script>
        function editUser(id, username, email, role) {
            document.getElementById('edit_user_id').value = id;
            document.getElementById('edit_username').value = username;
            document.getElementById('edit_email').value = email;
            document.getElementById('edit_role').value = role;
            document.getElementById('edit_password').value = '';
            document.getElementById('editModal').style.display = 'block';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function deleteUser(id, username) {
            if (confirm('Bạn có chắc muốn xóa người dùng "' + username + '"?\nTất cả bài viết, bình luận của người này cũng sẽ bị xóa.')) {
                fetch('../api/admin-user-delete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'user_id=' + id
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Đã xóa người dùng thành công');
                        location.reload();
                    } else {
                        alert('Lỗi: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Có lỗi xảy ra: ' + error);
                });
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('editModal');
            if (event.target == modal) {
                closeEditModal();
            }
        }
    </script>
</body>
</html>
