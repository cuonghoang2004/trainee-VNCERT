<?php
include '../config.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_post_id'])) {
    $post_id = intval($_POST['delete_post_id']);
    
    $conn = connectDB();
    
    // Delete related data
    $stmt = $conn->prepare("DELETE FROM post_likes WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $stmt->close();
    
    $stmt = $conn->prepare("DELETE FROM comments WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $stmt->close();
    
    $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $stmt->close();
    
    $conn->close();
}

$conn = connectDB();
$stmt = $conn->prepare("
    SELECT p.id, p.title, p.content, p.created_at, u.username, u.id as user_id,
           (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as likes,
           (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments
    FROM posts p
    JOIN users u ON p.user_id = u.id
    ORDER BY p.created_at DESC
");
$stmt->execute();
$posts = $stmt->get_result();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý bài viết - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../components/header.php'; ?>
    
    <main class="main-container">
        <div class="admin-header">
            <h1>Bài viết gần đây</h1>
        </div>
        
        <div class="admin-table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th style="width: 120px;">Người viết</th>
                        <th style="width: 200px;">Nội dung</th>
                        <th style="width: 100px;">Ngày đăng</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($post = $posts->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $post['id']; ?></td>
                            <td><?php echo htmlspecialchars($post['username']); ?></td>
                            <td title="<?php echo htmlspecialchars($post['content']); ?>">
                                <?php 
                                $content = htmlspecialchars($post['content']);
                                echo mb_strlen($content) > 50 ? mb_substr($content, 0, 50) . '...' : $content; 
                                ?>
                            </td>
                            <td><?php echo formatTime($post['created_at']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
    
    <?php include '../components/footer.php'; ?>
    <script src="../js/main.js"></script>
</body>
</html>
