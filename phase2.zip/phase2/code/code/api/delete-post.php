<?php
include '../config.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $post_id = intval($_POST['post_id'] ?? 0);
    
    if (empty($post_id)) {
        http_response_code(400);
        die(json_encode(['error' => 'ID bài viết không hợp lệ']));
    }
    
    $post = requirePostOwnershipOrAdmin($post_id);
    
    $conn = connectDB();
    
    // Delete related likes and comments
    $stmt = $conn->prepare("DELETE FROM post_likes WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $stmt->close();
    
    $stmt = $conn->prepare("DELETE FROM comments WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $stmt->close();
    
    // Delete post
    $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);
    
    if ($stmt->execute()) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Bài viết đã được xóa']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Lỗi khi xóa bài viết']);
    }
    
    $stmt->close();
    $conn->close();
} else {
    http_response_code(405);
    die('Method not allowed');
}
?>
