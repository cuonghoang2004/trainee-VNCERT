<?php
include '../config.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $post_id = intval($_POST['post_id'] ?? 0);
    $title = escape($_POST['title'] ?? '');
    $content = escape($_POST['content'] ?? '');
    
    if (empty($post_id) || empty($content)) {
        http_response_code(400);
        die(json_encode(['error' => 'Dữ liệu không hợp lệ']));
    }
    if (!empty($title) && mb_strlen($title) > 255) {
        http_response_code(400);
        die(json_encode(['error' => 'Tiêu đề quá dài (tối đa 255 ký tự)']));
    }
    
    $post = requirePostOwnershipOrAdmin($post_id);
    
    $conn = connectDB();
    if ($title === '') {
        // Không gửi title => giữ nguyên title hiện tại, chỉ cập nhật content
        $stmt = $conn->prepare("UPDATE posts SET content = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $content, $post_id);
    } else {
        $stmt = $conn->prepare("UPDATE posts SET title = ?, content = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("ssi", $title, $content, $post_id);
    }
    
    if ($stmt->execute()) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Bài viết đã được cập nhật']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Lỗi khi cập nhật bài viết']);
    }
    
    $stmt->close();
    $conn->close();
} else {
    http_response_code(405);
    die('Method not allowed');
}
?>
