<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = escape($_POST['username'] ?? '');
    $email = escape($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $full_name = escape($_POST['full_name'] ?? '');
    
    // Kiểm tra dữ liệu
    $errors = [];
    
    if (empty($username)) $errors[] = "Tên đăng nhập không được để trống";
    if (empty($email)) $errors[] = "Email không được để trống";
    if (empty($password)) $errors[] = "Mật khẩu không được để trống";
    if ($password !== $confirm_password) $errors[] = "Mật khẩu không khớp";
    if (strlen($password) < 6) $errors[] = "Mật khẩu phải ít nhất 6 ký tự";
    
    if (empty($errors)) {
        $conn = connectDB();
        
        // Kiểm tra username/email đã tồn tại
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $errors[] = "Tên đăng nhập hoặc email đã tồn tại";
        } else {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $email, $password_hash, $full_name);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = "Đăng ký thành công! Vui lòng đăng nhập.";
                redirect('../login.php');
            } else {
                $errors[] = "Lỗi khi tạo tài khoản";
            }
        }
        
        $stmt->close();
        $conn->close();
    }
    
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        redirect('../register.php');
    }
}
?>
