<?php
include '../config.php';

$query = escape($_GET['q'] ?? '');

if (strlen($query) < 2) {
    redirect('../index.php');
}

$conn = connectDB();

// Tìm kiếm bài viết
$stmt = $conn->prepare("
    SELECT p.*, u.username, u.avatar, 
           (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as likes_count,
           (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
           (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id AND user_id = ?) as is_liked
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE MATCH(p.title, p.content) AGAINST(? IN BOOLEAN MODE)
    OR MATCH(u.username) AGAINST(? IN BOOLEAN MODE)
    ORDER BY p.created_at DESC
    LIMIT 50
");

$user_id = isLoggedIn() ? $_SESSION['user_id'] : 0;
$stmt->bind_param("iss", $user_id, $query, $query);
$stmt->execute();
$results = $stmt->get_result();

$stmt->close();
$conn->close();
?>
