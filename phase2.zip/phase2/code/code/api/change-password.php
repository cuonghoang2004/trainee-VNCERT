<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

try {
    $user = getCurrentUser();
    
    // Get POST data
    $old_password = $_POST['old_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate input
    if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
        header("Location: ../change-password.php?error=" . urlencode("Vui lòng điền đầy đủ thông tin"));
        exit();
    }
    
    if ($new_password !== $confirm_password) {
        header("Location: ../change-password.php?error=" . urlencode("Mật khẩu mới không khớp"));
        exit();
    }
    
    if (strlen($new_password) < PASSWORD_MIN_LENGTH) {
        header("Location: ../change-password.php?error=" . urlencode("Mật khẩu mới phải có ít nhất " . PASSWORD_MIN_LENGTH . " ký tự"));
        exit();
    }
    
    // Verify old password
    $conn = connectDB();
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_data = $result->fetch_assoc();
    $stmt->close();
    
    if (!$user_data || !password_verify($old_password, $user_data['password'])) {
        $conn->close();
        header("Location: ../change-password.php?error=" . urlencode("Mật khẩu hiện tại không đúng"));
        exit();
    }
    
    // Update password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashed_password, $_SESSION['user_id']);
    
    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: ../change-password.php?success=1");
        exit();
    } else {
        $stmt->close();
        $conn->close();
        header("Location: ../change-password.php?error=" . urlencode("Có lỗi xảy ra, vui lòng thử lại"));
        exit();
    }
    
} catch (Exception $e) {
    error_log("Change password error: " . $e->getMessage());
    header("Location: ../change-password.php?error=" . urlencode("Có lỗi xảy ra"));
    exit();
}
?>
