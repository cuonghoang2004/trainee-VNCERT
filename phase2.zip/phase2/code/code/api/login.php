<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = escape($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $errors = [];
    
    if (empty($username)) $errors[] = "Tên đăng nhập không được để trống";
    if (empty($password)) $errors[] = "Mật khẩu không được để trống";
    
    if (empty($errors)) {
        $conn = connectDB();
        
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            redirect('../index.php');
        } else {
            $errors[] = "Tên đăng nhập hoặc mật khẩu không chính xác";
        }
        
        $stmt->close();
        $conn->close();
    }
    
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        redirect('../login.php');
    }
}
?>
