<?php
include '../config.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['user_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $role = $_POST['role'] ?? ROLE_USER;
    $password = $_POST['password'] ?? '';

    if ($id <= 0) {
        $_SESSION['errors'] = ['ID không hợp lệ'];
        redirect('../admin/users.php');
    }

    $errors = [];
    if ($username === '' || $email === '') {
        $errors[] = 'Vui lòng nhập đầy đủ username và email';
    }
    if (!isValidEmail($email)) {
        $errors[] = 'Email không hợp lệ';
    }
    if (!in_array($role, [ROLE_USER, ROLE_ADMIN, ROLE_MODERATOR], true)) {
        $errors[] = 'Vai trò không hợp lệ';
    }
    if ($errors) {
        $_SESSION['errors'] = $errors;
        redirect('../admin/users.php');
    }

    $conn = connectDB();

    // Check unique constraints except current user
    $stmt = $conn->prepare('SELECT id FROM users WHERE (username = ? OR email = ?) AND id <> ? LIMIT 1');
    $stmt->bind_param('ssi', $username, $email, $id);
    $stmt->execute();
    $exists = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($exists) {
        $_SESSION['errors'] = ['Tên đăng nhập hoặc email đã được dùng bởi người khác'];
        $conn->close();
        redirect('../admin/users.php');
    }

    if ($password !== '') {
        if (strlen($password) < PASSWORD_MIN_LENGTH) {
            $_SESSION['errors'] = ['Mật khẩu quá ngắn'];
            $conn->close();
            redirect('../admin/users.php');
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('UPDATE users SET username = ?, email = ?, full_name = ?, role = ?, password = ? WHERE id = ?');
        $stmt->bind_param('sssssi', $username, $email, $full_name, $role, $hash, $id);
    } else {
        $stmt = $conn->prepare('UPDATE users SET username = ?, email = ?, full_name = ?, role = ? WHERE id = ?');
        $stmt->bind_param('ssssi', $username, $email, $full_name, $role, $id);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = 'Cập nhật người dùng thành công';
    } else {
        $_SESSION['errors'] = ['Không thể cập nhật người dùng'];
    }
    $stmt->close();
    $conn->close();

    redirect('../admin/users.php');
} else {
    http_response_code(405);
    echo 'Method not allowed';
}
