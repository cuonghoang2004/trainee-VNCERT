<?php
include '../config.php';

requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['user_id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'ID không hợp lệ']);
        exit;
    }

    // Không tự xóa chính mình để tránh mất quyền quản trị
    if ($id == $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'Không thể tự xóa tài khoản đang đăng nhập']);
        exit;
    }

    $conn = connectDB();

    // Xóa dữ liệu liên quan (posts, comments, likes) nhờ ON DELETE CASCADE cho hầu hết, nhưng làm sạch likes/comment_likes nếu cần
    // MariaDB sẽ tự xử lý CASCADE nên chỉ cần xóa người dùng
    $stmt = $conn->prepare('DELETE FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Đã xóa người dùng']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Không thể xóa người dùng']);
    }
    $stmt->close();
    $conn->close();
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
