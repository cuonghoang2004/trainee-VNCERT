<?php
include '../config.php';

if (!isLoggedIn()) {
    http_response_code(401);
    exit('Unauthorized');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = escape($_POST['title'] ?? '');
    $content = escape($_POST['content'] ?? '');
    $user_id = $_SESSION['user_id'];
    
    if (empty($title)) {
        $_SESSION['errors'] = ["Tiêu đề không được để trống"];
        redirect('../index.php');
    }
    if (mb_strlen($title) > 255) {
        $_SESSION['errors'] = ["Tiêu đề quá dài (tối đa 255 ký tự)"];
        redirect('../index.php');
    }
    if (empty($content)) {
        $_SESSION['errors'] = ["Nội dung bài viết không được để trống"];
        redirect('../index.php');
    }
    
    $conn = connectDB();
    
    $stmt = $conn->prepare("INSERT INTO posts (user_id, title, content) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $title, $content);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Đăng bài thành công!";
    } else {
        $_SESSION['errors'] = ["Lỗi khi đăng bài"];
    }
    
    $stmt->close();
    $conn->close();
    
    redirect('../index.php');
}
?>
