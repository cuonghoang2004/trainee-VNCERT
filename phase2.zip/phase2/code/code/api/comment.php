<?php
include '../config.php';

if (!isLoggedIn()) {
    http_response_code(401);
    exit('Unauthorized');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $post_id = intval($_POST['post_id'] ?? 0);
    $content = escape($_POST['content'] ?? '');
    $user_id = $_SESSION['user_id'];
    
    if (empty($content) || $post_id <= 0) {
        $_SESSION['errors'] = ["Dữ liệu không hợp lệ"];
        redirect('../index.php');
    }
    
    $conn = connectDB();
    
    // Kiểm tra bài viết có tồn tại
    $stmt = $conn->prepare("SELECT id FROM posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows == 0) {
        $_SESSION['errors'] = ["Bài viết không tồn tại"];
        redirect('../index.php');
    }
    
    $stmt = $conn->prepare("INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $post_id, $user_id, $content);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Bình luận thành công!";
    } else {
        $_SESSION['errors'] = ["Lỗi khi bình luận"];
    }
    
    $stmt->close();
    $conn->close();
    
    redirect('../index.php');
}
?>
