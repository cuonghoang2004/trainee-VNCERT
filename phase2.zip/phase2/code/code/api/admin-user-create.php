<?php
include '../config.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? ROLE_USER;

    $errors = [];
    if ($username === '' || $email === '' || $password === '') {
        $errors[] = 'Vui lòng nhập đầy đủ username, email và mật khẩu';
    }
    if (!isValidEmail($email)) {
        $errors[] = 'Email không hợp lệ';
    }
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        $errors[] = 'Mật khẩu quá ngắn';
    }
    if (!in_array($role, [ROLE_USER, ROLE_ADMIN, ROLE_MODERATOR], true)) {
        $errors[] = 'Vai trò không hợp lệ';
    }

    if ($errors) {
        $_SESSION['errors'] = $errors;
        redirect('../admin/users.php');
    }

    $conn = connectDB();

    // Check unique username/email
    $stmt = $conn->prepare('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1');
    $stmt->bind_param('ss', $username, $email);
    $stmt->execute();
    $exists = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($exists) {
        $_SESSION['errors'] = ['Tên đăng nhập hoặc email đã tồn tại'];
        $conn->close();
        redirect('../admin/users.php');
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare('INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('sssss', $username, $email, $hash, $full_name, $role);

    if ($stmt->execute()) {
        $_SESSION['message'] = 'Tạo người dùng thành công';
    } else {
        $_SESSION['errors'] = ['Không thể tạo người dùng'];
    }
    $stmt->close();
    $conn->close();

    redirect('../admin/users.php');
} else {
    http_response_code(405);
    echo 'Method not allowed';
}
