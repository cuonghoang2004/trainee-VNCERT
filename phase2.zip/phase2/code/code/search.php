<?php 
include 'config.php';

$query = isset($_GET['q']) ? escape($_GET['q']) : '';

if (strlen($query) < 2) {
    redirect('index.php');
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tìm kiếm "<?php echo htmlspecialchars($query); ?>" - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'components/header.php'; ?>
    
    <main class="main-container">
        <div class="sidebar">
            <?php include 'components/sidebar.php'; ?>
        </div>
        
        <div class="feed">
            <h1>Kết quả tìm kiếm cho "<?php echo htmlspecialchars($query); ?>"</h1>
            
            <div class="posts-list">
                <?php
                $conn = connectDB();
                
                $user_id = isLoggedIn() ? $_SESSION['user_id'] : 0;
                $stmt = $conn->prepare("
                    SELECT p.*, u.username, u.avatar, u.id as user_id,
                           (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as likes_count,
                           (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                           (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id AND user_id = ?) as is_liked
                    FROM posts p
                    JOIN users u ON p.user_id = u.id
                    WHERE MATCH(p.title, p.content) AGAINST(? IN BOOLEAN MODE)
                    OR MATCH(u.username) AGAINST(? IN BOOLEAN MODE)
                    ORDER BY p.created_at DESC
                    LIMIT 50
                ");
                
                $stmt->bind_param("iss", $user_id, $query, $query);
                $stmt->execute();
                $posts = $stmt->get_result();
                
                if ($posts->num_rows > 0) {
                    while ($post = $posts->fetch_assoc()) {
                        include 'components/post-card.php';
                    }
                } else {
                    echo '<div class="empty-state"><p>Không tìm thấy kết quả nào</p></div>';
                }
                
                $stmt->close();
                $conn->close();
                ?>
            </div>
        </div>
    </main>
    
    <?php include 'components/footer.php'; ?>
    <!-- Changed from script.js to main.js for consistency -->
    <script src="js/main.js"></script>
</body>
</html>
