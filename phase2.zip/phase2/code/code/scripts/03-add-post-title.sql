-- Migration: Add title column to posts if not exists
ALTER TABLE posts ADD COLUMN title VARCHAR(255) NOT NULL DEFAULT '' AFTER user_id;
-- Backfill existing rows with truncated first 60 chars of content if title empty
UPDATE posts SET title = LEFT(content, 60) WHERE (title = '' OR title IS NULL);
-- Add combined fulltext index if not exists (MySQL/MariaDB lacks IF NOT EXISTS for indexes reliably)
-- Safe attempt: will fail if exists; ignore manually if needed
CREATE FULLTEXT INDEX ft_posts_title_content ON posts(title, content);
