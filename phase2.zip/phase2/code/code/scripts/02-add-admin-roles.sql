-- Migration script to add admin roles and update database schema
ALTER TABLE users ADD COLUMN role ENUM('user', 'admin', 'moderator') DEFAULT 'user' AFTER bio;

-- Create an admin user (password: admin123)
INSERT INTO users (username, email, password, full_name, role) 
VALUES ('admin', 'admin@socialhub.com', '$2y$10$Y9ykYvQeGqbsGKh5Z1Z9OuQz.z0XzXzXzXzXzXzXzXzXzXzXzXzXzXz', 'Administrator', 'admin')
ON DUPLICATE KEY UPDATE role='admin';
