<?php
require_once 'config.php';
requireLogin();

$user = getCurrentUser();
$error = '';
$success = '';

if (isset($_GET['success'])) {
    $success = 'Đổi mật khẩu thành công!';
}

if (isset($_GET['error'])) {
    $error = $_GET['error'];
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đổi mật khẩu - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'components/header.php'; ?>
    
    <main class="main-container">
        <div class="sidebar">
            <?php include 'components/sidebar.php'; ?>
        </div>
        
        <div class="feed">
            <div class="profile-section">
                <h2>🔒 Đổi mật khẩu</h2>
                
                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <form action="api/change-password.php" method="POST" class="profile-form">
                    <div class="form-group">
                        <label for="old_password">Mật khẩu hiện tại:</label>
                        <input type="password" id="old_password" name="old_password" required minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">Mật khẩu mới:</label>
                        <input type="password" id="new_password" name="new_password" required minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Xác nhận mật khẩu mới:</label>
                        <input type="password" id="confirm_password" name="confirm_password" required minlength="6">
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">Đổi mật khẩu</button>
                        <a href="profile.php" class="btn-secondary">Hủy</a>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="sidebar-right">
            <?php include 'components/trending.php'; ?>
        </div>
    </main>
    
    <?php include 'components/footer.php'; ?>
    <script src="js/main.js"></script>
</body>
</html>
