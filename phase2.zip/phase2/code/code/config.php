<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'social_network');

// Application Constants
define('APP_NAME', 'SocialHub');
define('APP_URL', 'http://localhost/social_network');
define('UPLOAD_DIR', __DIR__ . '/uploads/');

// User Roles
define('ROLE_USER', 'user');
define('ROLE_ADMIN', 'admin');
define('ROLE_MODERATOR', 'moderator');

// Pagination
define('POSTS_PER_PAGE', 10);
define('COMMENTS_PER_PAGE', 5);

// Security
define('PASSWORD_MIN_LENGTH', 6);
define('SESSION_TIMEOUT', 3600);
define('MAX_POST_LENGTH', 5000);
define('MAX_COMMENT_LENGTH', 1000);

// Database Connection Function
function connectDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Lỗi kết nối: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// Bootstrap - Initialize Session & Middleware
session_start();

// Check session timeout
if (isset($_SESSION['user_id']) && isset($_SESSION['last_activity'])) {
    if ((time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        session_destroy();
        header("Location: login.php?timeout=1");
        exit();
    }
}
$_SESSION['last_activity'] = time();

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Get current logged-in user
function getCurrentUser() {
    if (!isLoggedIn()) return null;
    
    $conn = connectDB();
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    return $user;
}

// Check user role
function hasRole($user, $role) {
    return $user && $user['role'] === $role;
}

// Check if user is admin or moderator
function isAdmin($user) {
    return hasRole($user, ROLE_ADMIN) || hasRole($user, ROLE_MODERATOR);
}

// Escape data
function escape($data) {
    $conn = connectDB();
    $escaped = $conn->real_escape_string($data);
    $conn->close();
    return $escaped;
}

// Redirect function
function redirect($path) {
    header("Location: " . $path);
    exit();
}

// Format timestamp
function formatTime($timestamp) {
    $time = strtotime($timestamp);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) return "vừa xong";
    if ($diff < 3600) return floor($diff / 60) . " phút trước";
    if ($diff < 86400) return floor($diff / 3600) . " giờ trước";
    if ($diff < 604800) return floor($diff / 86400) . " ngày trước";
    
    return date('d/m/Y', $time);
}

// Validate email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Upload file
function uploadFile($file, $folder = 'posts') {
    if (!file_exists(UPLOAD_DIR . $folder)) {
        mkdir(UPLOAD_DIR . $folder, 0755, true);
    }
    
    $filename = time() . '_' . basename($file['name']);
    $target_path = UPLOAD_DIR . $folder . '/' . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return '/uploads/' . $folder . '/' . $filename;
    }
    
    return null;
}

// Get post by ID
function getPostById($post_id) {
    $conn = connectDB();
    $stmt = $conn->prepare("SELECT p.*, u.username, u.avatar FROM posts p JOIN users u ON p.user_id = u.id WHERE p.id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $post = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    return $post;
}

// Require login
function requireLogin() {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
}

// Require admin
function requireAdmin() {
    requireLogin();
    $user = getCurrentUser();
    if (!isAdmin($user)) {
        http_response_code(403);
        die("Truy cập bị từ chối. Bạn không có quyền hạn quản trị.");
    }
}

// Require post ownership or admin
function requirePostOwnershipOrAdmin($post_id) {
    requireLogin();
    $post = getPostById($post_id);
    $user = getCurrentUser();
    
    if (!$post || ($post['user_id'] != $_SESSION['user_id'] && !isAdmin($user))) {
        http_response_code(403);
        die("Bạn không có quyền chỉnh sửa bài viết này.");
    }
    
    return $post;
}
?>
