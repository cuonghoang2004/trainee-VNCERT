import requests
import html
import argparse
import sys
import re
import platform
import os
import subprocess

class HelpOnErorrArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        self.print_help()
        sys.exit(2)

path = './exploit-db'

def extract_exploit_id(id):
    if id is None:
        return None
    
    id = str(id)
    m = re.search(r'(\d+)(?!.*\d)', id)

    return m.group(1) if m else None

def open_file(filepath):

    try:
        if platform.system() == "Windows":
            os.startfile(filepath)
        else:
            subprocess.run(["xdg-open", filepath], check=False)
    except Exception:
        print("Saved at:", filepath)

def exploit_func(id):
    id = extract_exploit_id(id)
    if id is None:
        print('Invalid ID')
        return

    filename = os.path.join(path, f"{id}.txt")
    
    # Tạo thư mục nếu chưa tồn tại
    os.makedirs(path, exist_ok=True)

    if os.path.exists(filename):
        open_file(filename)
        return
    else:
        url = f'https://www.exploit-db.com/exploits/{id}'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        try:
            res = requests.get(url, headers=headers)
            res.raise_for_status()  # Kiểm tra lỗi HTTP
        except requests.RequestException as e:
            print(f"Failed to fetch exploit {id}: {e}")
            return

        start_tag = '<code'
        end_tag = '</code>'
        start_idx = res.text.find(start_tag)
        end_idx = res.text.find(end_tag, start_idx)

        if start_idx == -1 or end_idx == -1:
            print(f"Could not find exploit code for ID {id}")
            return

        exploit_html = res.text[start_idx:end_idx + len(end_tag)]
        inner_start = exploit_html.find('">')
        if inner_start == -1:
            print(f"Could not parse exploit code for ID {id}")
            return

        exploit_code = html.unescape(exploit_html[inner_start + 2:])

        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(exploit_code)
            print(f"Saved exploit {id} to {filename}")
        except Exception as e:
            print(f"Failed to save exploit {id}: {e}")
            return

        # Mở file
        open_file(filename)

def page_func(pnum):
    try:
        pnum = int(pnum)
        if pnum < 0:
            print("Page number must be >= 0")
            return
    except ValueError:
        print("Invalid page number")
        return
    
    ids = []
    try:
        for fname in os.listdir(path):
            m = re.match(r'^(\d+)\.txt$', fname)
            if m:
                try:
                    ids.append(int(m.group(1)))
                except Exception:
                    pass
        ids.sort()
    except Exception:
        pass

    total_entries = len(ids)
    if pnum > total_entries // 5:
        print(f"Page number exceeds total pages ({total_entries // 5})")
        return
    entries_per_page = 5
    start = pnum * entries_per_page
    end = start + entries_per_page
    page_ids = ids[start:end]
    print('\n'.join(str(i) for i in page_ids))
    return

def search_regex_from_keyword(keyword):
    tokens = re.findall(r'[A-Za-z0-9]+', str(keyword))
    if not tokens:
        return None
    pattern = r'\b(' + '|'.join(re.escape(t) for t in tokens) + r')\b'
    return re.compile(pattern, re.IGNORECASE)

def search_func(keyword):
    cre = search_regex_from_keyword(keyword)
    if cre is None:
        print("No valid search tokens found.")
        return
    
    ids = []
    try:
        for fname in os.listdir(path):
            m = re.match(r'^(\d+)\.txt$', fname)
            if m:
                try:
                    ids.append(int(m.group(1)))
                except Exception:
                    pass
        ids.sort()
    except Exception:
        pass
    matched = []
    for eid in ids:
        fname = os.path.join(path, f"{eid}.txt")
        try:
            with open(fname, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            if cre.search(content):
                matched.append(eid)
        except Exception:
            continue
    if not matched:
        print("No stored exploits matched.")
        return
    matched.sort()
    print("\n".join( f"{path}/{str(x)}.txt" for x in matched))
    return

if __name__ == '__main__':

    parser = HelpOnErorrArgumentParser(
        description='Python Exam',
        add_help=True
    )
    parser.add_argument('--exploit', help='exploit ID', nargs='?')
    parser.add_argument('--page', help='get page', nargs='?')
    parser.add_argument('--search', help='Search keywords', nargs='?')
    args = parser.parse_args()

    if (not args.exploit and not args.page and not args.search):
        parser.print_help()
        sys.exit(0)

    if args.exploit:
        exploit_func(args.exploit)
        sys.exit(0)
    if args.page:
        page_func(args.page)
        sys.exit(0)
    if args.search:
        search_func(args.search)
        sys.exit(0)

